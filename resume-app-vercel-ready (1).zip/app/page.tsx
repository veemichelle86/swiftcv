import Link from "next/link";

export default function Page(){
  return (
    <div className="grid gap-8 md:grid-cols-2 items-center">
      <section className="space-y-6">
        <h1 className="text-4xl font-bold">Build a clean resume in minutes</h1>
        <p className="text-neutral-300">Free basic editor. One-click PDF export. Upgrade for premium templates and hosting.</p>
        <div className="flex gap-3">
          <Link href="/builder" className="btn btn-primary">Open Builder</Link>
          <Link href="/pricing" className="btn border border-neutral-700">See Pricing</Link>
        </div>
        <ul className="text-sm text-neutral-400 list-disc ml-5 space-y-2">
          <li>No account needed for free exports</li>
          <li>Premium: unlimited templates, custom link, analytics</li>
          <li>Cancel anytime</li>
        </ul>
      </section>
      <section className="card">
        <div className="h-64 rounded-xl bg-neutral-800 grid place-items-center">
          <span className="opacity-70">Resume preview</span>
        </div>
      </section>
    </div>
  );
}
