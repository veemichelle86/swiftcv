import "./globals.css";
import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Resume App",
  description: "Create, export, and share resumes. Upgrade for premium templates."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="border-b border-neutral-800">
          <nav className="container flex items-center justify-between py-4">
            <Link href="/" className="font-semibold">Resume App</Link>
            <div className="flex gap-4 text-sm">
              <Link href="/builder">Builder</Link>
              <Link href="/pricing">Pricing</Link>
            </div>
          </nav>
        </header>
        <main className="container py-10">{children}</main>
        <footer className="container py-10 text-sm text-neutral-400">
          © {new Date().getFullYear()} Resume App
        </footer>
      </body>
    </html>
  );
}
