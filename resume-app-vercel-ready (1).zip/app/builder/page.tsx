'use client';
import { useState } from 'react';

type Resume = {
  name: string;
  title: string;
  email: string;
  phone: string;
  summary: string;
  skills: string;
  experience: string;
  education: string;
};

const empty: Resume = {
  name: '', title: '', email: '', phone: '',
  summary: '', skills: '', experience: '', education: ''
};

export default function Builder(){
  const [data, setData] = useState<Resume>(empty);

  const download = () => {
    const blob = new Blob([
      `Name: ${data.name}\nTitle: ${data.title}\nEmail: ${data.email}\nPhone: ${data.phone}\n\nSummary\n${data.summary}\n\nSkills\n${data.skills}\n\nExperience\n${data.experience}\n\nEducation\n${data.education}\n`
    ], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'resume.txt'; // Simple export. Can swap to PDF later.
    a.click();
  };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="card">
        <h2 className="text-xl font-semibold mb-4">Resume Editor</h2>
        {Object.entries(data).map(([k,v]) => (
          <div key={k} className="mb-4">
            <label className="label">{k[0].toUpperCase()+k.slice(1)}</label>
            <textarea
              className="input h-24"
              value={v as string}
              onChange={(e)=>setData(prev=>({...prev, [k]: e.target.value}))}
            />
          </div>
        ))}
        <div className="flex gap-3">
          <button className="btn btn-primary" onClick={download}>Export</button>
          <button className="btn border border-neutral-700" onClick={()=>setData(empty)}>Clear</button>
        </div>
      </div>
      <div className="card">
        <h2 className="text-xl font-semibold mb-4">Live Preview</h2>
        <div className="prose prose-invert max-w-none">
          <h3 className="text-2xl">{data.name}</h3>
          <p className="text-neutral-400">{data.title} • {data.email} • {data.phone}</p>
          <h4 className="mt-4 font-semibold">Summary</h4>
          <p className="whitespace-pre-wrap">{data.summary}</p>
          <h4 className="mt-4 font-semibold">Skills</h4>
          <p className="whitespace-pre-wrap">{data.skills}</p>
          <h4 className="mt-4 font-semibold">Experience</h4>
          <p className="whitespace-pre-wrap">{data.experience}</p>
          <h4 className="mt-4 font-semibold">Education</h4>
          <p className="whitespace-pre-wrap">{data.education}</p>
        </div>
      </div>
    </div>
  );
}
