import Link from "next/link";

export default function PricingPage(){
  return (
    <div className="grid md:grid-cols-3 gap-6">
      <div className="card">
        <h3 className="text-xl font-semibold">Free</h3>
        <p className="text-neutral-400 mt-2">Basic builder + PDF export</p>
        <p className="text-3xl font-bold mt-4">$0</p>
        <Link href="/builder" className="btn btn-primary mt-6">Start Free</Link>
      </div>
      <div className="card border-2 border-white">
        <h3 className="text-xl font-semibold">Pro</h3>
        <p className="text-neutral-400 mt-2">Premium templates + hosting</p>
        <p className="text-3xl font-bold mt-4">$9<span className="text-xl">/mo</span></p>
        <form action="/api/checkout" method="POST" className="mt-6">
          <input type="hidden" name="priceId" value="price_pro_monthly" />
          <button className="btn btn-primary w-full" type="submit">Upgrade</button>
        </form>
      </div>
      <div className="card">
        <h3 className="text-xl font-semibold">Lifetime</h3>
        <p className="text-neutral-400 mt-2">One-time payment. All future templates.</p>
        <p className="text-3xl font-bold mt-4">$49</p>
        <form action="/api/checkout" method="POST" className="mt-6">
          <input type="hidden" name="priceId" value="price_lifetime" />
          <button className="btn w-full border border-neutral-700" type="submit">Buy</button>
        </form>
      </div>
    </div>
  );
}
