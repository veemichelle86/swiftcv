import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";

export async function POST(req: NextRequest) {
  try{
    const form = await req.formData();
    const priceId = String(form.get("priceId") || "price_lifetime");

    if(!process.env.STRIPE_SECRET_KEY || !process.env.NEXT_PUBLIC_URL){
      return NextResponse.json({error: "Missing env"}, { status: 400 });
    }

    const session = await stripe.checkout.sessions.create({
      mode: priceId === "price_pro_monthly" ? "subscription" : "payment",
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${process.env.NEXT_PUBLIC_URL}/pricing?success=1`,
      cancel_url: `${process.env.NEXT_PUBLIC_URL}/pricing?canceled=1`
    });

    return NextResponse.redirect(session.url!, { status: 303 });
  }catch(e:any){
    return NextResponse.json({error: e.message}, { status: 500 });
  }
}
