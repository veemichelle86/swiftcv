import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest){
  // TODO: Implement Stripe webhook verification with STRIPE_WEBHOOK_SECRET
  return NextResponse.json({ received: true });
}
