
import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { pdf, Document, Page, Text } from '@react-pdf/renderer';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2022-11-15' });

export async function GET(req, { params }) {
  const { searchParams } = new URL(req.url);
  const session_id = searchParams.get("session_id");

  if (!session_id) return new NextResponse("No session ID", { status: 401 });

  const session = await stripe.checkout.sessions.retrieve(session_id);
  if (!session || session.payment_status !== "paid") return new NextResponse("Not paid", { status: 403 });

  const blob = await pdf(
    <Document>
      <Page size="A4"><Text>✅ Resume PDF Ready</Text></Page>
    </Document>
  ).toBuffer();

  return new NextResponse(blob, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': 'inline; filename="resume.pdf"'
    }
  });
}
