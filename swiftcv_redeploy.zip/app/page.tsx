
export default function HomePage() {
  return (
    <main>
      <h1>SwiftCV Resume Builder</h1>
      <p>This is your future resume builder app.</p>
    </main>
  );
}
