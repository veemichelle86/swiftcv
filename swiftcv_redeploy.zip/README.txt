
SwiftCV - Resume Builder App

1. Upload contents to your GitHub repo (named 'swiftcv')
2. Import to Vercel
3. Add ENV variables in Vercel
4. Deploy live

Includes:
- Homepage
- API route to generate paid resume PDF
